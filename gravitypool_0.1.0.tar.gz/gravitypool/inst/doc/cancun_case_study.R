## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7.2,
  fig.height = 4.8,
  warning = TRUE,
  message = FALSE
)

## ----setup--------------------------------------------------------------------
library(gravitypool)
library(ggplot2)
library(dplyr)

## ----load_scenario------------------------------------------------------------
# Carga directa del archivo de investigación JSON integrado
escenario_cancun <- load_pool_scenario()
print(escenario_cancun)

## ----sim_pure_gravity---------------------------------------------------------
sim_pura <- simulate_gravity_system(escenario_cancun, mode = "pure_gravity")

# Métricas del tanque elevado requerido
sim_pura$tank_sizing

## ----plot_topo_pure-----------------------------------------------------------
plot_topography(sim_pura)

## ----sim_hybrid---------------------------------------------------------------
sim_bypass <- simulate_gravity_system(escenario_cancun, mode = "hybrid_bypass")

# Estado estructural
cat("Estado de Factibilidad:", sim_bypass$feasibility, "\n")
cat("Carga total a cimentación:", sim_bypass$tank_sizing$total_gross_load_tons, "Toneladas\n")
cat("Inversión Inicial:", scales::dollar(sim_bypass$capex_usd$total), "\n")

## ----plot_topo_hybrid---------------------------------------------------------
plot_topography(sim_bypass)

## ----sim_battery--------------------------------------------------------------
sim_bess <- simulate_battery_system(escenario_cancun)

cat("Capacidad Nominal Requerida:", sim_bess$battery_sizing$nameplate_capacity_kwh, "kWh\n")
cat("Módulos Rack (5 kWh c/u):", sim_bess$battery_sizing$battery_rack_modules_5kwh, "unidades\n")
cat("Inversión Inicial Baterías:", scales::dollar(sim_bess$capex_usd$total), "\n")

## ----comparison---------------------------------------------------------------
comparativa <- compare_scenarios(escenario_cancun)
print(comparativa)

## ----plot_lca-----------------------------------------------------------------
plot_lca_emissions(comparativa)

## ----plot_payback-------------------------------------------------------------
plot_financial_payback(comparativa)

## ----plot_capex---------------------------------------------------------------
plot_capex_breakdown(comparativa)

